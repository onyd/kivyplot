
from kivy.core.text import Label as CoreLabel
from kivy.uix.boxlayout import BoxLayout
from kivy.graphics import Ellipse, Line, Rectangle, Color, InstructionGroup, Callback
from kivy.properties import NumericProperty, ListProperty, ObjectProperty, BooleanProperty, StringProperty, ColorProperty, ReferenceListProperty
from kivy.uix.widget import Widget
import numpy as np
from kivy.graphics.fbo import Fbo
from kivy.metrics import sp
from kivy.event import EventDispatcher
from itertools import chain
import numpy as np
import colorsys
from collections import defaultdict
from kivyplot.plot.Legend import *
from kivy.core.window import Window
from kivyplot.utils.Tooltip import Tooltip
from kivy.clock import Clock
from matplotlib import cm

"""ID counter for new graphic element"""
ID = 1


class Plot2DElement(EventDispatcher):
    """Base class for graphic element in the Graph2D widget"""
    color = ColorProperty()
    tooltip_text = StringProperty()

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        global ID
        self.id = ID
        ID += 1

    def get_cid(self):
        """Convert the id to a color tuple used for picking"""
        r = self.id & 255
        g = (self.id & (255 << 8)) >> 8
        b = (self.id & (255 << 16)) >> 16
        return r, g, b

    def _get_color(self):
        return Color(rgba=self.color)

    def _get_picking_color(self):
        return Color(rgb=tuple(x / 255 for x in self.get_cid()))

    def _get_graphic_instructions(self, mapping_fn):
        raise NotImplementedError()

    def as_instructions(self, mapping_fn):
        return [self._get_color(), *self._get_graphic_instructions(mapping_fn)]

    def as_picking_instructions(self, mapping_fn):
        return [self._get_picking_color(), *self._get_graphic_instructions(mapping_fn)]


class Dot(Plot2DElement):
    pos = ListProperty()
    radius = NumericProperty()

    def _get_graphic_instructions(self, mapping_fn):
        x, y = mapping_fn(tuple(self.pos))[0]
        return [Ellipse(pos=[x-self.radius, y-self.radius],
                        size=[self.radius*2, self.radius*2])]


class Curve(Plot2DElement):
    points = ListProperty()
    width = NumericProperty()
    dash_length = NumericProperty(1)
    dash_offset = NumericProperty(0)

    def _get_graphic_instructions(self, mapping_fn):
        points = []
        for p in self.points:
            points.append(mapping_fn(tuple(p))[0])
        return [Line(points=points, width=self.width, dash_length=self.dash_length, dash_offset=self.dash_offset)]


class HRange(Plot2DElement):
    start = NumericProperty()
    end = NumericProperty()
    y = NumericProperty()
    tick_height = NumericProperty(sp(24))
    width = NumericProperty()

    def _get_graphic_instructions(self, mapping_fn):
        (start_x, start_y), (end_x, end_y) = mapping_fn(
            (self.start, self.y), (self.end, self.y))
        return [Line(points=[start_x, start_y-self.tick_height/2, start_x, start_y+self.tick_height/2], width=self.width), Line(points=[start_x, start_y, end_x, end_y], width=self.width), Line(points=[end_x, start_y-self.tick_height/2, end_x, end_y+self.tick_height/2], width=self.width)]


class Box(Plot2DElement):
    pos = ListProperty()
    size = ListProperty()

    def _get_graphic_instructions(self, mapping_fn):
        x, y = tuple(self.pos)
        (x1, y1), (x2, y2) = mapping_fn(
            (x, y), (x+self.size[0], y+self.size[1]))
        return [Rectangle(pos=[x1, y1], size=[x2-x1, y2-y1])]


class Bar(Plot2DElement):
    pos = ListProperty()
    width = NumericProperty()

    def _get_graphic_instructions(self, mapping_fn):
        x, y = tuple(self.pos)
        d = self.width/2
        (x1, y1), (x2, y2) = mapping_fn((x-d, 0), (x+d, y))
        return [Rectangle(pos=[x1, y1], size=[x2-x1, y2-y1])]


class Graph2D(Widget):
    """Graph widget which draws axis and given data"""
    margin = NumericProperty(sp(38))
    arrow_size = NumericProperty(sp(6))

    stepx = NumericProperty(0.2)
    stepy = NumericProperty(0.2)
    step = ReferenceListProperty(stepx, stepy)

    xmin = NumericProperty(-1)
    xmax = NumericProperty(1)
    ymin = NumericProperty(-1)
    ymax = NumericProperty(1)
    bounding_box = ReferenceListProperty(xmin, ymin, xmax, ymax)

    x_axis_mapping = ObjectProperty(lambda x: x)
    y_axis_mapping = ObjectProperty(lambda x: x)

    data = ListProperty([])

    def __init__(self, picking=True, **kwargs) -> None:
        super().__init__(**kwargs)
        self.picking = picking
        if self.picking:
            self.cid_to_element = {}

        self.bind(
            margin=self.update,
            arrow_size=self.update,
            step=self.update,
            bounding_box=self.update,
            x_axis_mapping=self.update,
            y_axis_mapping=self.update,
        )
        self.setup()

    def to_viewport_space(self, *points):
        result = []
        for x, y in points:
            result.append((
                (x-self.xmin) / (self.xmax-self.xmin) *
                (self.width-2*self.margin) + self.margin,
                (y-self.ymin) / (self.ymax-self.ymin) * (self.height-2*self.margin) + self.margin))
        return tuple(result)

    def update(self, *args):
        self.update_axes()
        self.update_data()

    def update_data(self, *args):
        self.draw_data()
        if self.picking:
            self.draw_picking_data()

    def update_axes(self):
        self.axes_instructions.clear()
        self.axes_instructions.add(Color(rgb=(0, 0, 0)))

        # Graph
        self.axes_instructions.add(Line(
            rectangle=[1, 1, self.width-1, self.height-1], width=1))

        # -- x axis --
        x_axis_points = self.to_viewport_space(
            (self.xmin, self.ymin), (self.xmax, self.ymin))
        self.axes_instructions.add(
            Line(points=[*x_axis_points[0], *x_axis_points[1]], width=1))

        # arrow
        arrow_x, arrow_y = self.to_viewport_space((self.xmax, self.ymin))[0]
        self.axes_instructions.add(
            Line(points=[arrow_x-self.arrow_size, arrow_y+self.arrow_size, arrow_x, arrow_y, arrow_x-self.arrow_size, arrow_y-self.arrow_size], width=1))

        # ticks
        x_right_ticks = np.arange(self.stepx, self.xmax, self.stepx)
        x_left_ticks = np.arange(self.xmin, 0, self.stepx)
        for x in chain(x_left_ticks, x_right_ticks):
            vx, vy = self.to_viewport_space((x, self.ymin))[0]
            self.axes_instructions.add(
                Line(points=[vx, vy+self.arrow_size/2, vx, vy-self.arrow_size/2], width=1))
            tick_label = CoreLabel(
                text=f"{self.x_axis_mapping(round(x, 2))}", font_size=10)
            tick_label.refresh()
            texture = tick_label.texture
            self.axes_instructions.add(Rectangle(texture=texture, pos=[
                vx-texture.width/2, vy-texture.height-self.arrow_size], size=texture.size))
        # -- y axis --
        y_axis_points = self.to_viewport_space(
            (self.xmin, self.ymin), (self.xmin, self.ymax))
        self.axes_instructions.add(
            Line(points=[*y_axis_points[0], *y_axis_points[1]], width=1))

        # arrow
        arrow_x, arrow_y = self.to_viewport_space((self.xmin, self.ymax))[0]
        self.axes_instructions.add(
            Line(points=[arrow_x+self.arrow_size, arrow_y-self.arrow_size, arrow_x, arrow_y, arrow_x-self.arrow_size, arrow_y-self.arrow_size], width=1))

        # ticks
        y_right_ticks = np.arange(self.stepy, self.ymax, self.stepy)
        y_left_ticks = np.arange(self.ymin, 0, self.stepy)
        for y in chain(y_left_ticks, y_right_ticks):
            vx, vy = self.to_viewport_space((self.xmin, y))[0]
            self.axes_instructions.add(
                Line(points=[vx+self.arrow_size/2, vy, vx-self.arrow_size/2, vy], width=1))
            tick_label = CoreLabel(
                text=f"{self.y_axis_mapping(round(y, 2))}", font_size=10)
            tick_label.refresh()
            texture = tick_label.texture
            self.axes_instructions.add(Rectangle(texture=texture, pos=[
                vx-texture.width-self.arrow_size, vy-texture.height/2], size=texture.size))

    def get_element_at(self, x, y):
        assert(self.picking)
        try:
            return self.cid_to_element[tuple(self.picking_fbo.get_pixel_color(x, y))[:3]]
        except KeyError:
            return None

    def draw_data(self):
        self.instructions.clear()
        for element in self.data:
            for instr in element.as_instructions(self.to_viewport_space):
                self.instructions.add(instr)

    def draw_picking_data(self):
        self.picking_instructions.clear()
        for element in self.data:
            for instr in element.as_picking_instructions(self.to_viewport_space):
                self.picking_instructions.add(instr)

    def setup(self):
        with self.canvas:
            self._viewport = Rectangle(size=self.size, pos=self.pos)
            self.fbo = Fbo(size=self.size,
                           with_depthbuffer=False, compute_normal_mat=False,
                           clear_color=(1., 1., 1., 1.))
            if self.picking:
                self.picking_fbo = Fbo(size=self.size,
                                       with_depthbuffer=False, compute_normal_mat=False,
                                       clear_color=(0., 0., 0., 1.))

        with self.fbo:
            Callback(self._clear_buffer)
            self.axes_instructions = InstructionGroup()
            self.instructions = InstructionGroup()

        if self.picking:
            with self.picking_fbo:
                Callback(self._clear_picking_buffer)
                self.picking_instructions = InstructionGroup()

        self._viewport.texture = self.fbo.texture
        self.bind(size=self._adjust_aspect)
        Clock.schedule_once(self.update)

    def _clear_buffer(self, *args):
        self.fbo.clear_buffer()

    def _clear_picking_buffer(self, *args):
        self.picking_fbo.clear_buffer()

    def add_points(self, points, color=(0, 0, 1, 1), radius=5, tooltip_text=''):
        for p in points:
            e = Dot(pos=p, radius=radius, color=color,
                    tooltip_text=tooltip_text)
            if self.picking:
                self.cid_to_element[e.get_cid()] = e
            self.data.append(e)

    def add_curve(self, points, color=(0, 0, 1, 1), width=1, tooltip_text='', dash_length=1, dash_offset=0):
        e = Curve(points=points, color=color,
                  width=width, tooltip_text=tooltip_text, dash_length=dash_length, dash_offset=dash_offset)
        if self.picking:
            self.cid_to_element[e.get_cid()] = e
        self.data.append(e)

    def add_hrange(self, y, start, end, width=1, color=(0, 0, 0, 1), tooltip_text=''):
        r = HRange(start=start,
                   end=end,
                   y=y,
                   width=width,
                   color=color,
                   tooltip_text=tooltip_text)
        if self.picking:
            self.cid_to_element[r.get_cid()] = r
        self.data.append(r)

    def add_box(self, pos, size, color=(0, 0, 1, 1), tooltip_text=''):

        box = Box(pos=pos,
                  size=size,
                  color=color,
                  tooltip_text=tooltip_text)

        if self.picking:
            self.cid_to_element[box.get_cid()] = box
        self.data.append(box)

    def add_bars(self, *points, color=(0, 0, 1, 1), width=1, tooltip_text=''):
        for p in points:
            e = Bar(pos=p, width=width, color=color, tooltip_text=tooltip_text)
            if self.picking:
                self.cid_to_element[e.get_cid()] = e
            self.data.append(e)

    def clear(self):
        self.data.clear()
        self.cid_to_element.clear()
        self.update_data()

    def _adjust_aspect(self, inst, val):
        if self.width > 0 and self.height > 0:
            self.fbo.size = self.size
            self._viewport.size = self.size
            self._viewport.pos = self.pos
            self._viewport.texture = self.fbo.texture

            if self.picking:
                self.picking_fbo.size = self.size
            self.update()


class Plot2D(BoxLayout):
    do_show_legend = BooleanProperty(False)

    def __init__(self, show_hover_data=True, **kwargs):
        super().__init__()
        # Setup widget
        self.spacing = sp(12)
        self.bind(minimum_size=self.setter('size'))
        self.graph = Graph2D(**kwargs)
        self.legend = None
        self.labels = []
        self.add_widget(self.graph)
        self.bind(pos=self.update, size=self.update)

        # Setup tooltip
        if show_hover_data:
            self._tooltip = None
            self.hovered = None
            Window.bind(mouse_pos=self.on_mouse_pos)

            self.closed = True

    def _update_tooltip(self, x, y):
        e = self.graph.get_element_at(x, y)
        if e is None:
            if not self.closed:
                self.close_tooltip()
            return False
        if e is self.hovered:
            self._tooltip.pos = (x, y)
            return False

        # The element has changed
        if not self.closed:
            self.close_tooltip()
        self.hovered = e
        self._tooltip = Tooltip(text=e.tooltip_text)
        return True

    def on_mouse_pos(self, *args):
        if not self.get_root_window():
            return
        pos = args[1]
        if not self._update_tooltip(*pos):
            return

        # close if it's opened
        if self.collide_point(*self.to_parent(*self.to_widget(*pos))):
            if self.closed:
                self.display_tooltip()

    def close_tooltip(self, *args):
        Window.remove_widget(self._tooltip)
        self.hovered = None
        self.closed = True

    def display_tooltip(self, *args):
        Window.add_widget(self._tooltip)
        self.closed = False

    def on_do_show_legend(self, *args):
        if self.legend is None:
            self.legend = Legend()
            self.add_widget(self.legend)
        else:
            self.remove_widget(self.legend)

    def update_legend(self, *args):
        if self.do_show_legend:
            self.legend.clear_widgets()
            for label in self.labels:
                self.legend.add_widget(label)

    def update(self, *args):
        self.canvas.before.clear()
        with self.canvas.before:
            Color(rgb=(1, 1, 1))
            Rectangle(pos=self.pos, size=self.size)

    def scatter(self, points, color=(0, 0, 1, 1), radius=5, label=None, tooltip_text=''):
        self.graph.add_points(points, color=color,
                              radius=radius, tooltip_text=tooltip_text)
        if label is not None:
            self.labels.append(DotLegendItem(
                label=label, color=color, radius=radius))
        self.update_legend()

    def plot(self, points, color=(0, 0, 1, 1), width=1, label=None, tooltip_text=''):
        self.graph.add_curve(points, color=color,
                             width=width, tooltip_text=tooltip_text)
        if label is not None:
            self.labels.append(CurveLegendItem(
                label=label, color=color, line_width=width))
        self.update_legend()
        self.graph.update_data()

    def bars(self, points, color=(0, 0, 1, 1), width=1, label=None, tooltip_text=''):
        self.graph.add_bars(*points, color=color,
                            width=width, tooltip_text=tooltip_text)
        if label is not None:
            self.labels.append(BarLegendItem(
                label=label, color=color))
        self.update_legend()
        self.graph.update_data()

    def box(self, names, data, show_mean=True, show_median=True):
        data = np.array(data)
        mx = float(data.max())
        mn = float(data.min())

        self.graph.xmin = mn-0.1*(mx-mn)
        self.graph.xmax = mx+0.1*(mx-mn)
        self.graph.ymin = 0
        self.graph.ymax = len(data)+1
        self.graph.stepx = 10**(int(np.log10(mx))-1)*len(data)
        self.graph.stepy = 1
        #self.graph.y_axis_mapping = lambda y: names[int(y)]

        for i, d in enumerate(data):
            y = len(data)-i
            self.graph.add_hrange(
                y=y, start=float(d.min()), end=float(d.max()))

            box_height = 0.75
            q = np.quantile(d, [0.25, 0.75])
            self.graph.add_box(
                pos=(q[0], y-box_height/2), size=(q[1]-q[0], box_height))
            if show_mean:
                mean = float(d.mean())
                self.graph.add_curve(
                    points=[(mean, y-box_height/2), (mean, y+box_height/2)],
                    color=(1, 0, 0, 1))
            if show_median:
                med = float(np.median(d))
                self.graph.add_curve(
                    points=[(med, y-box_height/2), (med, y+box_height/2)],
                    color=(0, 1, 0, 1))
        self.update_legend()
        self.graph.update_data()

    def heatmap(self, matrix, x_labels=None, y_labels=None, cmap='viridis'):
        matrix = np.array(matrix)
        mx = matrix.max()
        mn = matrix.min()

        self.graph.xmin, self.graph.ymin = 0, 0
        self.graph.ymax = matrix.shape[0] + 1
        self.graph.xmax = matrix.shape[1] + 1
        self.graph.stepx = 1
        self.graph.stepy = 1
        if x_labels:
            self.graph.x_axis_mapping = lambda x: x_labels[int(x)-1]
        if y_labels:
            self.graph.y_axis_mapping = lambda y: y_labels[int(y)-1]

        cmap = cm.get_cmap(cmap)

        def color(x):
            return cmap((x-mn) / (mx-mn))

        for i in range(matrix.shape[0]):
            for j in range(matrix.shape[1]):
                x = j+0.5
                y = matrix.shape[0]-i-0.5
                self.graph.add_box(pos=(x, y),
                                   size=(1, 1),
                                   color=color(matrix[i][j]),
                                   tooltip_text=str(matrix[i][j]))
        self.update_legend()
        self.graph.update_data()

    def hist(self, labels):
        h = defaultdict(int)
        for label in labels:
            h[label] += 1
        my = max(h.values())
        X = list(h.keys())
        labels_to_index = {l: i for i, l in enumerate(X, start=1)}

        HSV = {l: (i/len(h), 0.5, 0.9) for i, l in enumerate(h)}
        colors = {k: (*colorsys.hsv_to_rgb(*v), 1) for k, v in HSV.items()}

        self.graph.xmin = 0
        self.graph.xmax = len(h)+1
        self.graph.ymin = 0
        self.graph.ymax = my
        self.graph.stepx = 1
        self.graph.stepy = 10**(int(np.log10(my))-1)*len(h)
        self.graph.x_axis_mapping = lambda x: X[int(x)-1]

        for x, y in h.items():
            self.bars([(labels_to_index[x], y)],
                      color=colors[x], width=0.9, label=str(x))

    def clear(self):
        self.graph.clear()
