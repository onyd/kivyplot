class VertexGroup(object):
    def __init__(self, *indicies):
        self.indicies = indicies
